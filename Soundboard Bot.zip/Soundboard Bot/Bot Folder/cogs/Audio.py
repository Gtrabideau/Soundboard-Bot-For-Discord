import os
from pathlib import Path
import discord
from discord import FFmpegPCMAudio
from discord.ext import commands
from discord import Interaction, Attachment
import csv


# The command to play sound. Outside of classes so that it is able to work with discord's button view system.
async def play(ctx, arg):
    # Boolean to register if a sound was played or if there was a problem
    played_bool = False

    # Check if user is not in a voice channel, otherwise continue
    if ctx.author.voice is None:
        await ctx.send('You are not in a voice channel.', ephemeral=True)
    else:
        # Join the user's channel
        channel = ctx.message.author.voice.channel
        if ctx.voice_client is not None:
            await ctx.voice_client.move_to(channel)
        else:
            await channel.connect()

        # Find the file in the audio folder.
        voice = ctx.guild.voice_client
        for filename in os.listdir('./cogs/audioClips'):
            if not filename.endswith('.csv'):
                # Check if the file name provided matches a file with or without its file extension text
                if arg == filename or arg == Path(filename).stem:
                    sound = f'./cogs/audioClips/{filename}'
                    source = FFmpegPCMAudio(sound)
                    player = voice.play(source)
                    played_bool = True

        if played_bool:
            await ctx.send(f'Playing: {arg}', ephemeral=True)
        else:
            await ctx.send(f'{arg} was not found in your audio clips.', ephemeral=True)


# The button view that discord bots use
class SoundButtons(discord.ui.View):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx

        # Convert the .csv data folder to a dictionary that can be used for binding buttons to audio clips.
        with open('./cogs/audioClips/audioData.csv', 'r') as csvfile:
            reader = csv.reader(csvfile)
            self.board_dict = {rows[1]: rows[0] for rows in reader}

    # Command to quickly check if the button is bound and then call the play method.
    async def check_board(self, button_num: str):
        if button_num in list(self.board_dict.keys()):
            await play(self.ctx, self.board_dict[button_num])
        else:
            await self.ctx.send("No sound is bound to this button. Use the ?set command to set a saved sound to a "
                                "button", ephemeral=True)

    # All 9 buttons for the board. Defer actions are to stop discord from saying the action failed.
    @discord.ui.button(label="1", style=discord.ButtonStyle.red, row=1)
    async def s1(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="2", style=discord.ButtonStyle.red, row=1)
    async def s2(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="3", style=discord.ButtonStyle.red, row=1)
    async def s3(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="4", style=discord.ButtonStyle.red, row=2)
    async def s4(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="5", style=discord.ButtonStyle.red, row=2)
    async def s5(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="6", style=discord.ButtonStyle.red, row=2)
    async def s6(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="7", style=discord.ButtonStyle.red, row=3)
    async def s7(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="8", style=discord.ButtonStyle.red, row=3)
    async def s8(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()

    @discord.ui.button(label="9", style=discord.ButtonStyle.red, row=3)
    async def s9(self, interaction: Interaction, button: discord.ui.Button):
        await self.check_board(button.label)
        await interaction.response.defer()


class Audio(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # The path to the .csv data file
        self.soundIndex = './cogs/audioClips/audioData.csv'

    # Used to add a sound to the data file. Returns true if the file was written to, false otherwise.
    async def write_to_csv(self, ctx, name: str):
        # Boolean to move into overwriting an entry that is already in the data file
        overwrite_mode = False

        # Check data file for same entry as the user's input
        with open(self.soundIndex, mode='r') as csvfile:
            reader = csv.reader(csvfile, delimiter=',')
            for row in reader:
                for field in row:
                    if field == name:
                        overwrite_mode = True
        if overwrite_mode:
            def check(m):  # Method for checking if the same user is responding
                return m.author == ctx.author and m.channel == ctx.channel

            # Confirm if they want to overwrite
            await ctx.send("There is already a file of this name. Do you want to overwrite it? (yes/no)",
                           ephemeral=True)

            try:  # waiting for message
                response = await client.wait_for('message', check=check,
                                                 timeout=30.0)  # timeout - how long bot waits for message (in seconds)
            except asyncio.TimeoutError:  # returning after timeout
                await ctx.send("Timeout: I will not overwrite the file.", ephemeral=True)
                return False

            # If response isn't 'yes' or 'y,' then don't overwrite.
            if response.content.lower() not in ("yes", "y"):
                await ctx.send("Ok, I will not overwrite the file.", ephemeral=True)
                return False
            else:
                await ctx.send("Understood, overwriting file.", ephemeral=True)
                return True
        # If you are not overwriting, simply add the file to the list with no soundboard button
        else:
            with open(self.soundIndex, mode='a') as csvfile:
                csvfile.write(str(name) + ',0' + '\n')
            return True

    # Used to bind sound files to soundboard buttons or delete files from the data file.
    def change_csv(self, delete_mode: bool, name: str, board_num=0):
        # Used to keep track of the line of the file in question.
        entry_line = None

        with open(self.soundIndex, mode='r') as csvfile:
            # Turn data into a list, then start the file from the beginning again
            data = csvfile.readlines()
            csvfile.seek(0)

            # Go through every entry to find the line the targeted data is on
            reader = csv.reader(csvfile, delimiter=',')
            for row in reader:
                for field in row:
                    if field == name or Path(field).stem == Path(name).stem:
                        entry_line = reader.line_num
                        # Ensure that the name used has the extension text of the original data
                        name = field
        # Simply delete the line if in delete mode. Otherwise, change the line to add the button number
        if delete_mode:
            del data[entry_line - 1]
        else:
            data[entry_line - 1] = str(name) + ',' + str(board_num) + '\n'

        # Rewrite the file with the new data
        with open(self.soundIndex, mode='w') as csvfile:
            for line in data:
                csvfile.write(line)

    # Command to open the board. Most of the work is done within the view itself
    @commands.command()
    async def board(self, ctx):
        view = SoundButtons(ctx)
        await ctx.send(view=view)
        await view.wait()

    # For setting a saved sound to a board number
    # Can use the original attachment if it is already saved, but will only go off of the files name
    @commands.command()
    async def set(self, ctx, arg: str | Attachment, board_num=None):
        # Variables for getting the file's name and checking if the file exists
        file_name = None
        file_exists = False

        # Set the file name for if the user gave a string or attachment
        if isinstance(arg, str):
            file_name = arg
        elif isinstance(arg, Attachment):
            file_name = arg.filename

        # Check if the file exists, skip over the data file
        for filename in os.listdir('./cogs/audioClips'):
            if not filename.endswith('.csv'):
                if (file_name == filename) or (Path(file_name).stem == Path(filename).stem):
                    file_exists = True

        # If the file was not found, end the method
        if not file_exists:
            await ctx.send('I can\'t find this file in your saved sounds.')
            return

        # Correcting the use of the command if the user did not give a usable button number to bind their audio to
        if (board_num is None) or (int(board_num) > 9) or (int(board_num) < 1):
            ctx.send('I can\'t seem to find which button you want to set this file to. Please use this command in the '
                     'format: ?set (filename/Attachment) (number from 1-9)',
                     ephemeral=True)
        # If there are no issues, change the csv file to the given button.
        else:
            self.change_csv(False, file_name, board_num)
            await ctx.send(f'File, {file_name}, has been set to board number {board_num}', ephemeral=True)

    # Play command that the user can actually call
    @commands.command()
    async def play(self, ctx, arg):
        await play(ctx, arg)

    # Saves an attachment locally and enters it into the local data file
    @commands.command()
    async def save(self, ctx, attachment: Attachment):
        # Checks the attachments MIME data type for audio files
        if attachment.content_type[:6] != 'audio/':
            await ctx.send('This is not a recognized audio file.', ephemeral=True)
        else:
            # If writing to the csv is successful, then save the actual audio file
            if await self.write_to_csv(ctx, attachment.filename):
                await attachment.save('./cogs/audioClips/' + attachment.filename)
                await ctx.send(f'{attachment.filename} saved.', ephemeral=True)

    # Deletes an already saved audio file and removes it from the data file
    @commands.command()
    async def delete(self, ctx, arg):
        # boolean for if deletion was successful
        delete_bool = False

        # Check audio folder for the user's input
        for filename in os.listdir('./cogs/audioClips'):
            if not filename.endswith('.csv'):
                if (arg == filename) or (Path(arg).stem == Path(filename).stem):
                    # Use delete mode in change_csv to remove it from the data folder
                    self.change_csv(True, filename)
                    # Remove the actual audio file
                    os.remove('./cogs/audioClips/' + filename)
                    delete_bool = True

        if delete_bool:
            await ctx.send(f'{arg} has been deleted from your audio clips.', ephemeral=True)
        else:
            await ctx.send(f'{arg} was not found in your audio clips.', ephemeral=True)

    @commands.command()
    async def list(self, ctx):
        file_list = []
        list_string = ''
        with open('./cogs/audioClips/audioData.csv', 'r') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)
            for row in reader:
                file_list.append(row[0])
                list_string += f'{row[0]}, '
                if row[1] != '0':
                    list_string += f'Soundboard Button: {row[1]},'
                list_string += '\n'
        if len(file_list) == 0:
            await ctx.send('You have no saved sounds.', ephemeral=True)
        else:
            await ctx.send(list_string, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Audio(bot))
