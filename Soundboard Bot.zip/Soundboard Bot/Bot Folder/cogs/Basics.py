import discord
from discord import FFmpegPCMAudio
from discord.ext import commands


class Basics(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self) -> None:
        print(f'{self.bot.user} is now running!')

    # Ping command to test if the bot is working.
    @commands.command()
    async def ping(self, ctx):
        ping_embed = discord.Embed(title='Ping', description='Latency in ms', color=discord.Color.blurple())
        ping_embed.add_field(name=f'{self.bot.user.name}\'s Latency (ms): ',
                             value=f'{round(self.bot.latency * 1000)}ms.', inline=False)
        ping_embed.set_footer(text=f'Requested by {ctx.author.name}.', icon_url=ctx.author.avatar)
        await ctx.send(embed=ping_embed)

    # Gives a list of commands that the bot can use.
    @commands.command()
    async def help(self, ctx):
        ping_embed = discord.Embed(title='Help', description='list and description of commands',
                                   color=discord.Color.blurple())
        ping_embed.add_field(name='?join',
                             value='This command makes the bot join your current voice channel.',
                             inline=False)
        ping_embed.add_field(name='?leave',
                             value='This command makes the bot leave whatever voice channel it is in.',
                             inline=False)
        ping_embed.add_field(name='?ping',
                             value='This command gives the bots latency.',
                             inline=False)
        ping_embed.add_field(name='?save (Audio attachment)',
                             value='Use this command with an audio attachment to save the audio file to the '
                                   'bots folder on your local system. You can add an attachment to a post by using Discord\'s built in attachment system or by copy and pasting the file into the message field.', inline=False)
        ping_embed.add_field(name='?play (Audio name)',
                             value='Use this command to play the audio you saved. You can use the name of the sound with or without the extention.\nExample: ?play sound.mp3 or ?play sound'
                             , inline=False)
        ping_embed.add_field(name='?delete (Audio name)',
                             value='Use this command to delete a previously saved audio file. You can use the name of the sound with or without the extention.\nExample: ?delete sound.mp3 or ?delete sound',
                             inline=False)
        ping_embed.add_field(name='?list',
                             value='Use this command to list the saved audio clips and if they are bound to the soundboard.',
                             inline=False)
        ping_embed.add_field(name='?set (Audio name) (Board number)',
                             value='Use this command to set one of your saved audio files to the soundboard. This command requires you to give the name of the audio, similar to play or delete, and then a number (1 to 9) to indicate which button of the soundboard you want the sound to be on.\nExample: ?set sound.mp3 1 or ?set sound 7',
                             inline=False)
        ping_embed.add_field(name='?board',
                             value='Use this command to open the soundboard. If you have not used the ?set command to set audio files to the buttons, the buttons will not do anything. After you set a audio file to a button, you can press the buttons on the board to play the bound sound.',
                             inline=False)
        ping_embed.set_footer(text=f'Requested by {ctx.author.name}.', icon_url=ctx.author.avatar)
        await ctx.send(embed=ping_embed)

    # Used to join voice channels. Not currently necessary, as the bot will automatically join in most other commands.
    @commands.command(pass_context=True)
    async def join(self, ctx):
        print('1')
        if ctx.author.voice:
            print('2')
            channel = ctx.author.voice.channel
            print('3')
            await channel.connect()
            print('4')
        else:
            print('5')
            await ctx.send("You are not in a voice channel, you must be in a voice channel to run this command.",
                           ephemeral=True)
            print('6')

    # Used to leave channels, for when the bot is no longer wanted for the time.
    @commands.command(pass_context=True)
    async def leave(self, ctx):
        if ctx.voice_client:
            await ctx.guild.voice_client.disconnect()
            await ctx.send('I left the voice channel.', ephemeral=True)
        else:
            await ctx.send("I am not in a voice channel.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Basics(bot))
