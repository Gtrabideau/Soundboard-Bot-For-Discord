import asyncio
from typing import Final
import os
from dotenv import load_dotenv
import json

import discord
from discord.ext import commands


# Load bot token
load_dotenv()
TOKEN: Final[str] = os.getenv('DISCORD_TOKEN')

# Create the bot with proper intents as well as removing default help command
intents = discord.Intents.default()
intents.message_content = True  # NOQA
bot = commands.Bot(intents=intents, command_prefix='?')
bot.remove_command('help')


# Function for loading cogs
async def load_cogs():
    initial_extensions = []
    for filename in os.listdir('./cogs'):
        if filename.endswith('.py'):
            await bot.load_extension(f'cogs.{filename[:-3]}')


# MAIN ENTRY POINT
async def main() -> None:
    async with bot:
        await load_cogs()
        await bot.start(TOKEN)


if __name__ == '__main__':
    asyncio.run(main())
